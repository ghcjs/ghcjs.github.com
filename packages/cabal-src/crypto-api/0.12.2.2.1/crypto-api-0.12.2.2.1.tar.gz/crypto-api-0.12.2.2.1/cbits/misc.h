#ifndef CRYPTO_API_MISC_H
#define CRYPTO_API_MISC_H
int c_constTimeEq(char *x, char *y, int length);
#endif
