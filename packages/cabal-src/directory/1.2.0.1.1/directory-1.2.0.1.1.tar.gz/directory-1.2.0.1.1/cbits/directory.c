#if defined(__GLASGOW_HASKELL__) || defined(__HUGS__)
/* 
 * (c) The University of Glasgow 2002
 *
 */

#define INLINE
#include "HsDirectory.h"

#endif

