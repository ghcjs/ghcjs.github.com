import Distribution.Simple
main :: IO ()
main = defaultMain
