{-# LANGUAGE PatternGuards, ViewPatterns #-}
