{-# LANGUAGE MultiParamTypeClasses
#-}
f :: Int
f = 4