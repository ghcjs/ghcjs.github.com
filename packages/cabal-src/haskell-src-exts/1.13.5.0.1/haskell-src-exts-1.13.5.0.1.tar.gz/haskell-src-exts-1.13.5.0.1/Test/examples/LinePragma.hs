{-# LINE 1 "Algebra.lhs" #-}
module Algebra where

{-# LINE 3 "Algebra.lhs" #-}
foo bar = bar