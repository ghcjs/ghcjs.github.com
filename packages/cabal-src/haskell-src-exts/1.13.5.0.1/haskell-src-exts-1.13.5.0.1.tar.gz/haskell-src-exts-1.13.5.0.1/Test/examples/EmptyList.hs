module EmptyList where

eAttrs = []