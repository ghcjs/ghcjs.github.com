import Test.QuickCheck
-- prop_susShortest = 2 > 1 ==> 1 /= 2
