
foo x y = fromIntegral $ x-y+1
