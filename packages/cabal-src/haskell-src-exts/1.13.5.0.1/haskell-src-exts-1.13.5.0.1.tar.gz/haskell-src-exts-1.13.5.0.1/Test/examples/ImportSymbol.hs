import Data.Generics hiding ((:*:))
