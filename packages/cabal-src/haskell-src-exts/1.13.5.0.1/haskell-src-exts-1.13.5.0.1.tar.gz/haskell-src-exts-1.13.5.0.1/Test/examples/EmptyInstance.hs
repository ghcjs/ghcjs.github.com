instance Traversable Tree where

x :: Int
x = 1
