yes = 1 where x = 1
