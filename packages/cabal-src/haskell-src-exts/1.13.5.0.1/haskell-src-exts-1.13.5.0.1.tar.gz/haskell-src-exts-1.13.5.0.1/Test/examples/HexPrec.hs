module HexPrec where

(%%) :: Int -> Int -> Int
a %% b = 0

infixl 0x02 %%