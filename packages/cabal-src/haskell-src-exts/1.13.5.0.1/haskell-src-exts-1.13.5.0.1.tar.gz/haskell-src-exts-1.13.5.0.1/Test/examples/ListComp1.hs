copyFiles =  [a | f ('.':)]
