happyThen :: () => P a
