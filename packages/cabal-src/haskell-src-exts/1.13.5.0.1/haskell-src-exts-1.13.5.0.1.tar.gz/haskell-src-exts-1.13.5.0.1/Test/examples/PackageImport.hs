{-# LANGUAGE PackageImports #-}

import "haskell-src-exts" Language.Haskell.Exts

main = undefined