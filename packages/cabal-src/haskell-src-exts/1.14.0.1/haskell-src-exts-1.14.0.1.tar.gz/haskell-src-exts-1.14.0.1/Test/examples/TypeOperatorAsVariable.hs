{-# LANGUAGE TypeOperators #-}

type T (~>) = ()

type Foo = ()
