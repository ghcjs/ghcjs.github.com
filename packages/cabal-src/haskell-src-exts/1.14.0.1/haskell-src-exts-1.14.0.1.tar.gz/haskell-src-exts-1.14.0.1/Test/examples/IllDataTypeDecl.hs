{-# LANGUAGE TypeOperators #-}
module IllDataTypeDecl where
  
data (f :+: g) p = L
