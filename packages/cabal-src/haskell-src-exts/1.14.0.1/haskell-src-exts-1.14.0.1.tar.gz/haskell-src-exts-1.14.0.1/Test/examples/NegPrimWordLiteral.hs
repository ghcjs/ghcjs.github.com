{-# LANGUAGE MagicHash #-}
dummyWord = W# (-0x8000000000000000##)
