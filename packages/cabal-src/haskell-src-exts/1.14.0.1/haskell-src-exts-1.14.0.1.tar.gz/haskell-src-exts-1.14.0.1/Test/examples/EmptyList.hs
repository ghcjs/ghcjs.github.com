module EmptyList where

eAttrs = []