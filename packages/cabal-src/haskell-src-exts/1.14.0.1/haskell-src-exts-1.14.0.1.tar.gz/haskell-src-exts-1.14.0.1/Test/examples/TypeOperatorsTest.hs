{-# LANGUAGE TypeOperators, FlexibleContexts, FlexibleInstances #-}

f :: ArrowXml (~>) => a ~> a
f = undefined
