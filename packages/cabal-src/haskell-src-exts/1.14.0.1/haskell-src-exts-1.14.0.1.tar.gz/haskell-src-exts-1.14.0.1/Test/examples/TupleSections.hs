{-# LANGUAGE TupleSections #-}

foo x = (1,,) x 3