module SCCPragmas where

x = {-# SCC "wibble" #-} 3