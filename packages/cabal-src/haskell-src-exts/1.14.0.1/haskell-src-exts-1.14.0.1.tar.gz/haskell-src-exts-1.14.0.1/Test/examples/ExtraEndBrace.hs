module ExtraEndBrace where

data A = B {c :: D}}
