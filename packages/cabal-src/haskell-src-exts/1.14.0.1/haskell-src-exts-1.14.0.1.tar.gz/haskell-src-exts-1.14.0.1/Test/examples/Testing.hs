{-# LINE 5 "templates\GenericTemplate.hs" #-}
main = return ()