module QualifiedDot where

twoDots = (Prelude..)