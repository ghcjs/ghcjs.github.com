module NestedAsPat where

nestedAsPat [x@(Just _)] = undefined