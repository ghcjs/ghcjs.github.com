{-# LANGUAGE MagicHash #-}
minInt = I# (0x8000000000000000#)
